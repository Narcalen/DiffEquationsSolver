#pragma once

void solveMatrix (int n, double *a, double *c, double *b, double *f, double *x);